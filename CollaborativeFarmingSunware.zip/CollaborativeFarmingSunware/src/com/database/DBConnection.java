package com.database;

import io.github.cdimascio.dotenv.Dotenv;
import java.sql.*;

public class DBConnection {
    private static Connection con;

    // Method to get database connection
    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                // Load environment variables
                Dotenv dotenv = Dotenv.configure()
                .directory("D:/CollaborativeFarmingSunware/CollaborativeFarmingSunware")
                .load();
                String url = dotenv.get("DB_URL");
                String userName = dotenv.get("DB_USER");
                String password = dotenv.get("DB_PASSWORD");

                // Load PostgreSQL Driver
                Class.forName("org.postgresql.Driver");
                con = DriverManager.getConnection(url, userName, password);
                System.out.println("Database Connected Successfully");
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Database Connection Error");
            e.printStackTrace();
        }
        return con;
    }

    // Method to close connection
    public static void closeConnection() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Database Connection Closed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
