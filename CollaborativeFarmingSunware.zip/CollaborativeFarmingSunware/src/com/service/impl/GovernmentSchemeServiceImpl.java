package com.service.impl;

import com.dao.GovernmentSchemeDAO;
import com.dao.impl.GovernmentSchemeDAOImpl;
import com.service.GovernmentSchemeService;
import java.time.LocalDate; // Import LocalDate
import java.util.List;
import java.util.Map;

public class GovernmentSchemeServiceImpl implements GovernmentSchemeService {
    private final GovernmentSchemeDAO schemeDAO = new GovernmentSchemeDAOImpl();

    // Method to add a new government scheme with validation
    public void addGovernmentScheme(String title, double benefitAmount, String startDate, String lastDate, String description) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Scheme title cannot be empty.");
        }
        if (benefitAmount <= 0) {
            throw new IllegalArgumentException("Error: Benefit amount must be greater than zero.");
        }
        if (startDate == null || startDate.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Start date cannot be empty.");
        }
        if (lastDate == null || lastDate.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: End date cannot be empty.");
        }
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Description cannot be empty.");
        }

        // Validate that the start date is today or a future date
        LocalDate currentDate = LocalDate.now();
        LocalDate start = LocalDate.parse(startDate);
        if (start.isBefore(currentDate)) {
            throw new IllegalArgumentException("Error: Start date cannot be before the current date.");
        }

        // Validate that the end date is after the start date
        LocalDate end = LocalDate.parse(lastDate);
        if (end.isBefore(start)) {
            throw new IllegalArgumentException("Error: End date must be after the start date.");
        }

        schemeDAO.insertScheme(title, benefitAmount, startDate, lastDate, description);
    }

    // Method to apply for a government scheme with validation
    public void applyForScheme(int farmerId, int schemeId) {
        if (farmerId <= 0 || schemeId <= 0) {
            throw new IllegalArgumentException("Error: Farmer ID and Scheme ID must be positive integers.");
        }
        
        schemeDAO.insertApplication(farmerId, schemeId);
    }

    // Method to update the application status with validation
    public void updateApplicationStatus(int applicationId, String status) {
        if (applicationId <= 0) {
            throw new IllegalArgumentException("Error: Application ID must be a positive integer.");
        }
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Status cannot be empty.");
        }
        
        List<String> validStatuses = List.of("Pending", "Accepted", "Rejected");
        if (!validStatuses.contains(status)) {
            throw new IllegalArgumentException("Error: Invalid status! Allowed values are: " + validStatuses);
        }
        
        schemeDAO.updateApplicationStatus(applicationId, status);
    }

    // Method to view applications by status with validation
    public List<Map<String, Object>> viewApplicationsByStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Status cannot be empty.");
        }
        
        List<String> validStatuses = List.of("Pending", "Accepted", "Rejected");
        if (!validStatuses.contains(status)) {
            throw new IllegalArgumentException("Error: Invalid status! Allowed values are: " + validStatuses);
        }
        
        return schemeDAO.getApplicationsByStatus(status);
    }

    // Method to view all available government schemes
    public List<Map<String, Object>> viewAllSchemes() {
        List<Map<String, Object>> schemes = schemeDAO.getAllSchemes();
        if (schemes == null || schemes.isEmpty()) {
            throw new IllegalStateException("No government schemes available.");
        }
        return schemes;
    }
}
